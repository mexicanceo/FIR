from django.contrib import admin

from fir_threatintel.models import YetiProfile

admin.site.register(YetiProfile)
