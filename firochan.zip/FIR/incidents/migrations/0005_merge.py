# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from django.db import models, migrations


class Migration(migrations.Migration):

    dependencies = [
        ('incidents', '0002_auto_20150907_1147'),
        ('incidents', '0004_delete_old_artifact_file'),
    ]

    operations = [
    ]
